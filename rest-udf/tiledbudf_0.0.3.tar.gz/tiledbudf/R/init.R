.onLoad <- function(libname, pkgname) {
    tiledbinotify::setDefault();
    #debugme::debugme()   ## -- slows things down too much
}
