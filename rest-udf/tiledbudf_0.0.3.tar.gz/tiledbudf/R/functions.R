# Package-internal function
from_JSON_string_or_file_no_funny_business <- function(path_or_text, isFile) {
  # If the file doesn't exist then we get the cryptic
  #   Error: lexical error: invalid char in json text.
  # so we are doing people a favor by first checking for existence.
  if (isFile) {
    stopifnot(file.exists(path_or_text))
  }
  # The extra options are because by default jsonlite likes to "simplify" our data "for us".
  jsonlite::fromJSON(path_or_text, simplifyVector=FALSE, simplifyDataFrame=FALSE, simplifyMatrix=FALSE, flatten=FALSE, autounbox=FALSE)
}

#' The \code{from_JSON_file_no_funny_business} function loads JSON into R
#' objects with JSON lists becoming R lists, and JSON objects becoming R
#' named lists.  This is necessary because by default R's jsonlite likes
#' to do things like taking \code{[{"a":1,"b":2}]} and doing us the favor
#' of treating it as if it were \code{{"a":1,"b":2}}. I want none of that.
#'
#' @title Read JSON into R with high fidelity, not collapsing container structures.
#' @param path A path to a file containing JSON.
#' @return R data in the form of numbers, strings, lists, named lists.
#' @export
from_JSON_file_no_funny_business <- function(path) {
  # If the file doesn't exist then we get the cryptic
  #   Error: lexical error: invalid char in json text.
  # so we are doing people a favor by first checking for existence.
  stopifnot(!is.null(path))
  stopifnot(file.exists(path))
  from_JSON_string_or_file_no_funny_business(path, TRUE)
}

#' The \code{from_JSON_string_no_funny_business} function loads JSON into R
#' objects with JSON lists becoming R lists, and JSON objects becoming R
#' named lists.  This is necessary because by default R's jsonlite likes
#' to do things like taking \code{[{"a":1,"b":2}]} and doing us the favor
#' of treating it as if it were \code{{"a":1,"b":2}}. I want none of that.
#'
#' @title Read JSON into R with high fidelity, not collapsing container structures.
#' @param text JSON string.
#' @return R data in the form of numbers, strings, lists, named lists.
#' @export
from_JSON_string_no_funny_business <- function(text) {
  stopifnot(!is.null(text))
  from_JSON_string_or_file_no_funny_business(text, FALSE)
  jsonlite::fromJSON(text, simplifyVector=FALSE, simplifyDataFrame=FALSE, simplifyMatrix=FALSE, flatten=FALSE, autounbox=FALSE)
}

#' The \code{show_file_contents} function is a debug helper for users of this
#' package, as well as functions in this package. Since the IPC UDF mechanism
#' is very JSON-file-heavy, easy inspection of raw JSON is essential for
#' developer sanity/productivity.
#'
#' @title Dump a JSON file as-is, without any parsing by R.
#' @param path A path to a file containing JSON.
#' @return No return value.
#' @export
show_file_contents <- function(path) {
  cat("CONTENTS OF ", path, " START\n")
  cat(readChar(path, file.info(path)$size), "\n")
  cat("CONTENTS OF ", path, " END\n")
  invisible()
}

#' The \code{read_script_parameters} function loads the central "args
#' file" prepared by the REST server into an in-memory data structure.
#' This includes intifying a couple int attributes which (bizarrely) come
#' in as strings, and kebab-to-snaking attribute names like \code{foo-bar}
#' to \code{foo_bar} so callers can do simply \code{p$foo_bar} in place of
#' the unwieldy \code{p$`foo-bar`}.
#'
#' @title Read args-file JSON into memory, with data-neatens.
#' @param path A path to a file containing JSON args-file data.
#' @return An R named list containing the parsed parameters.
#' @export
read_script_parameters <- function(path, verbose=FALSE) {
  cat("Arguments file name: ", path, "\n")

  if (!file.exists(path)) {
      stop("Input file does not exist.", call.=FALSE)
  }

  # Show JSON per se:
  if (verbose) {
    show_file_contents(path)
  }

  args_file_contents <- from_JSON_file_no_funny_business(path)

  # Show R's rendering of parsed JSON:
  if (verbose) {
    print("Parsed arguments-file contents:")
    print(args_file_contents)
  }

  list(
    message_size  = strtoi(args_file_contents$`message-size`),
    # The string comes to us like "\"json\"" rather than "json"
    result_format = gsub("\"", "", args_file_contents$`result-format`),
    result_size   = strtoi(args_file_contents$`result-size`),

    udf           = args_file_contents$`udf`,
    udf_args      = args_file_contents$`udf-args`,

    array_wrapper_path = args_file_contents$`array-wrapper-path`,
    message_path       = args_file_contents$`message-path`,
    rest_signal_path   = args_file_contents$`rest-signal-path`,
    result_path        = args_file_contents$`result-path`,
    telemetry_path     = args_file_contents$`telemetry-path`,
    udf_signal_path    = args_file_contents$`udf-signal-path`
  )
}

#' The \code{write_message} function writes a message regarding the state of IPC with payload.
#'
#' @title Write message
#' @param state The state of the IPC to write to message file
#' @param payload The payload of the state to write to message file
#' @param message_file The message file location
write_message <- function(state, payload, message_file) {
    msgjson <- jsonlite::toJSON(list(state=state, payload=payload),auto_unbox=TRUE)
    write(msgjson, file=message_file)
}

#' The \code{write_message_and_wait_confirmation} implements the IPC between
#' REST server and UDF process
#'
#' @title Write message and wait for confirmation
#' @param fd A file descriptor as returned by the C level function \code{open}
#' @param rest_signal_path A character variable with the path to the rest (server) signal
#' @param udf_signal_path A character variable with the path to the udf (client) signal
#' @param state The state of the IPC to write to message file
#' @param payload The payload of the state to write to message file
#' @param message_file The message file location
#' @param retry_interval An optional integer with the number of (initial) seconds to wait,
#' defaults to 5
#' @param max_try  An optional integer with the maximum number of seconds to wait,
#' defaults to 10
#' @return An error code that is either 0 on success or timeout, or -1 on unspecified error
#' (from inotify), -2 on an error with \code{errno}, or -3 if the rest file does not exist
#' @export
write_message_and_wait_confirmation <- function(fd, rest_signal_path, 
    udf_signal_path, state, payload, message_file, retry_interval=5L, max_try=10L) {
    
    file.create(udf_signal_path, showWarnings=TRUE)
    Sys.chmod(udf_signal_path, mode="0666", use_umask=FALSE)
    
    write_message(state, payload, message_file)

    file.create(rest_signal_path, showWarnings=TRUE)
    Sys.chmod(rest_signal_path, mode="0666", use_umask=FALSE)

    res <- tiledb_inotify_add_delete_watch(fd, rest_signal_path)

    unlink(udf_signal_path)

    while (TRUE) {
        wfdres <- tiledb_wait_for_delete(fd, retry_interval)
        logInfoMsg(sprintf("Got (%d, %d) in write_message_and_wait_confirmation on %s", res, wfdres, rest_signal_path))
        if (wfdres == 1L)               # success
            break
        if (wfdres == 0L)               # unexpected non-standard error
            return(-1)
        if (wfdres == -1L) {            # error setting errno
            cat(tiledb_strerror(), "\n")
            return(-2)
        }
        if (wfdres == -2L)              # timeout
            break

        ## Increase the retry interval by 1 second.
        retry_interval <- retry_interval + 1

        ## Clamp the maximum wait time to 5 seconds.
        retry_interval <- min(max_try, retry_interval)

    }
}

#' The \code{results_to_arrow} function converts the HTTP body,
#' as returned by the REST server, to Arrow format.
#' @param result HTTP body from a request to the REST server.
#' @return Result in Arrow format.
results_to_arrow <- function(result) {
    if (!is.data.frame(result)) {
      result <- as.data.frame(result)
    }

    result_table <- arrow::Table$create(result)

    sink <- arrow::BufferOutputStream$create()
    writer <- arrow::RecordBatchStreamWriter$create(sink, result_table$schema)

    writer$write(result)
    writer$close()
    as.raw(sink$finish())
}

#' The \code{write_result_to_result_path} function serializes an R
#' UDF result and sends it back to the REST server using our
#' file-based IPC mechanism.
#' @title Serialize R UDF result and send it to the REST server via IPC.
#' @param p Parsed arg-file data, as returned from read_script_parameters.
#' @param result An R object, returned from the supplied UDF -- not
#' serialized, as we will serialize it.
#' @return Nothing. Errors will be detected and handled server-side, e.g.
#' if we invoke stop().
#' @importFrom mmap as.mmap int8 munmap
#' @export
write_result_to_result_path <- function(p, result) {
  resmmap <- as.mmap(1:p$result_size, mode=int8(), file=p$result_path)

  if (is.null(resmmap)) {
    stop("resmmap is null\n")
  }

  # Set up inotify
  fd <- tiledbinotify::tiledb_inotify_init()

  # Serialize results according to requested format
  switch(p$result_format,
    native={
      cereal <- serialize(result, NULL)
    },
    json={
      cereal <- charToRaw(serializeJSON(result, digits = 8, pretty = FALSE))
    },
    arrow={
      cereal <- results_to_arrow(result)
    },
    stop("Result format unrecognized: ", p$result_format)
  )

  total_message_size <- as.integer(length(cereal))

  tiledbudf::write_message_and_wait_confirmation(fd, p$rest_signal_path, p$udf_signal_path, 2L,
  sprintf("%d", total_message_size), p$message_path)

  logInfoMsg("** Ready for main loop")

  # Magic numbers 1,2,3,4 confirm to the IPC protocol at TileDB-Cloud-REST/internal/tasks/udfs/exec/ipc.go.
  messageStateError            <- 1L
  messageStateResultSize       <- 2L
  messageStateResultReadyRead  <- 3L
  messageStateResultReadyWrite <- 4L

  num_bytes_written <- 0L
  while (TRUE) {
    b <- total_message_size - num_bytes_written
    b <- min(b, p$result_size)

    resmmap[1:b] <- cereal[num_bytes_written+1:as.integer(num_bytes_written+b)]
    num_bytes_written <- num_bytes_written + b

    write_message_and_wait_confirmation(fd, p$rest_signal_path, p$udf_signal_path,
      messageStateResultReadyRead, sprintf("%d", b), p$message_path)

    msg <- from_JSON_file_no_funny_business(p$message_path)
    if (num_bytes_written < total_message_size) {
      if (msg$state == messageStateError)
          stop("Unable to write partial results: ", msg$payload, call.=FALSE)
      if (msg$state != messageStateResultReadyWrite)
        stop("Unable to write partial results: Unexpected state ", msg$payload, messageStateResultReadyWrite, call.=FALSE)
    } else {
      logInfoMsg(sprintf("Received state %d, total received now at %s", msg$state, msg$payload))
      print("Results returned.")
      break
    }
  }

  logInfoMsg("** After main loop")

  munmap(resmmap)

  logInfoMsg("DONE")

  invisible()
}
