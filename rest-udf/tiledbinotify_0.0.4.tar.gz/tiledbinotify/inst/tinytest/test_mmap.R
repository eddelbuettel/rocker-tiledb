library(tinytest)
library(tiledbinotify)

hasMmap <- requireNamespace("mmap", quietly=TRUE)
if (hasMmap) library(mmap)

## create a new temp. filename, file does NOT yet exist
mmapfile <- tempfile()

## mmap package example:  store Dates as natural-size 'int' on disk
datevec <- Sys.Date() + 0:9
writeBin(as.integer(datevec), mmapfile)
if (hasMmap) {
    ## now mmap the content
    mmdates <- mmap(mmapfile, extractFUN=function(x) structure(x,class="Date"))
    dates <- mmdates[]
    expect_equal(datevec, dates)
    munmap(mmdates)
}

inf <- file.info(mmapfile)              # meta data
#print(str(inf))

fd <- tiledb_open(mmapfile)
expect_true(fd > 0)

xptr <- tiledb_mmap(fd, inf$size)
ivec <- tiledb_mmap_read(xptr, inf$size)
dvec <- as.Date(ivec, origin="1970-01-01")
expect_equal(datevec, dates)

res <- tiledb_munmap(xptr, inf$size)
expect_equal(res, 0L)

unlink(mmapfile)

set.seed(42)
N <- 10000
vec <- as.integer(rnorm(N) * 1e6)   	# some random payload

writeBin(vec, mmapfile)                 		  # write it out
fd <- tiledb_open(mmapfile)             		  # get fd
xptr <- tiledb_mmap(fd, N*sizeof(integer)) 		  # mmap it
ivec <- tiledb_mmap_read(xptr, N*sizeof(integer)) # mmap read
expect_equal(ivec, vec)                           # check

ivec <- ivec * 2                        # change vector
tiledb_mmap_write(xptr, ivec)           # write back
vec <- readBin(mmapfile, integer(), N)  # read to check
expect_equal(ivec, vec)                 # check

## -- round robin test
## create a new temp. filename, file does NOT yet exist
mmapfile <- tempfile()
fd <- tiledb_open(mmapfile)
expect_true(fd > 0)
N <- 100000
ivec <- sample(1:N)                     # sample to avoid ALTREP
sz <- N * sizeof(integer)
xptr <- tiledb_mmap(fd, sz)
tiledb_mmap_write(xptr, ivec)           # write
tiledb_munmap(xptr, sz)                 # unmap
tiledb_close(fd)

fd <- tiledb_open(mmapfile)
expect_true(fd > 0)
xptr <- tiledb_mmap(fd, sz)
ivec2 <- tiledb_mmap_read(xptr, sz)     # write back
expect_equal(ivec, ivec2)
tiledb_munmap(xptr, sz)                 # unmap
tiledb_close(fd)
