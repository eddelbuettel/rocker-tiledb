
library(tinytest)
library(tiledbinotify)

hasFuture <- requireNamespace("future", quietly=TRUE)
if (hasFuture) {
    library(future)
    plan(multisession)  # for future
}

## create a new temp. filename, file does NOT yet exist
watchedfile <- tempfile()

## set up inotifu
fd <- tiledb_inotify_init()

res <- tiledb_inotify_add_delete_watch(fd, watchedfile)
expect_equal(res, -1L) 					# file does not exist

wfdres <- tiledb_wait_for_delete(fd, 1L)
expect_equal(wfdres, -2L)           	# file does not exist, timing out

file.create(watchedfile)                # now create file

res <- tiledb_inotify_add_delete_watch(fd, watchedfile)
expect_equal(res, 1L) 					# file does exist

if (hasFuture) {
    deleteFile %<-% {                   # use future to delete file after sleeping
        Sys.sleep(0.5)
        unlink(watchedfile)
    }

    wfdres <- tiledb_wait_for_delete(fd, 1L)
    expect_equal(wfdres, 1L)            # file existed, was deleted
}

resfd <- tiledb_open(watchedfile)
expect_true(resfd > 0)                  # file descriptor generall posive integer

res <- tiledb_close(resfd)
expect_equal(res, 0L)                   # zero on successful close
