#include <Rcpp.h>
//using namespace Rcpp;

#include <stdio.h>

// Although we are deploying to Linux, we provide OS X mocks to
// allow it to compile for developers.
#ifdef __APPLE__

void *tiledb_mmap(const int fd, const size_t length) {
    return 0;
}

int tiledb_inotify_add_delete_watch(int fd, const char *pathname) {
    return -1;
}

int tiledb_wait_for_delete(const int fd, const int timeout_s) {
    return -1;
}

int tiledb_close(const int fd) {
    return -1;
}

void tiledb_free(void *const ptr) {
}

int tiledb_munmap(void *const addr, const size_t len) {
    return -1;
}

int tiledb_inotify_init() {
    return -1;
}

int tiledb_inotify_rm_watch(const int fd, const int wd) {
    return -1;
}

char *tiledb_strerror() {
    return 0;
}

#else // Linux

#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <sys/inotify.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <poll.h>
#include <unistd.h>

extern int errno;

//' Open a file and return the file descriptor
//'
//' @param file A character variable with the filename
//' @return An integer with the file descriptor
// [[Rcpp::export]]
int tiledb_open(std::string file) {
    int flags = O_RDWR | O_CREAT;
    int mode = S_IRWXU | S_IRWXG;
    int res = open(file.c_str(), flags, mode);
    if (res == -1) Rcpp::Rcout << std::string(strerror(errno)) << std::endl;
    return(res);
}

//' Memory-map a file descriptor
//'
//' @param fd An integer file descriptor
//' @param length A size_t (integer) length of the \code{mmap} segement
//' @param truncate A logical toggle whether the file descriptor is set to
//' the given sizes, default to \code{true}
//' @return A external pointer wrapper around the pointer from \code{mmap}.
// [[Rcpp::export]]
SEXP tiledb_mmap(const int fd, const size_t length, const bool truncate = true) {
    const int prot = PROT_READ | PROT_WRITE;
    const int flags = MAP_SHARED;
    if (truncate)
        if (ftruncate(fd, (off_t) length) == -1)
            Rcpp::Rcout << std::string(strerror(errno)) << std::endl;
    void *p = mmap(NULL, length, prot, flags, fd, 0);
    if (p == MAP_FAILED) Rcpp::Rcout << std::string(strerror(errno)) << std::endl;
    //Rcpp::Rcout << "MMAP address p is " << p << std::endl;
    return p == MAP_FAILED ? R_NilValue : R_MakeExternalPtr(p, R_NilValue, R_NilValue);
}

//' Add a 'delete' watch
//'
//' @param fd An integer file descriptor
//' @param pathname A character variable with the path and filename of the
//' file to watch.
//' @return An integer with the non-negative watch descriptor
// [[Rcpp::export]]
int tiledb_inotify_add_delete_watch(int fd, std::string pathname) {
    const int mask = IN_DELETE_SELF;
    const int wd = inotify_add_watch(fd, pathname.c_str(), mask);
    return wd;
}

//' Poll a file descriptor
//'
//' Waits for 'fd' to be readable for up to 'timeout_s' seconds.
//' @param fd An integer file descriptor
//' @param timeout_s An integer file with a timeout length
//' @return An integer with result: 0 for an unexpected,
//' non-std err, -1 for an error that set 'errno', -2 for
//' a timeout, or 1 for success.
// [[Rcpp::export]]
int tiledb_poll(const int fd, const int timeout_s) {
    struct pollfd fds[1];
    fds[0].fd = fd;
    fds[0].events = POLLIN;
    const int selected = poll(fds, 1, (timeout_s * 1000));

    // If poll() returned without selecting any file descriptors,
    // the operation timed out.
    if (selected == 0) {
        return -2;
    }

    // A return value of -1' indicates that an error occured.
    if (selected <= -1) {
        return -1;
    }

    // Return 0 if we don't recieve our expected event. This is
    // reasonably unexpected behavior.
    if (!(fds[0].revents & POLLIN)) {
        return 0;
    }

    // Return a positive integer to indicate success. This should
    // always be '1'.
    return selected;
}

//' Wait for deletion
//'
//' When a watched file is deleted, it will generate the following three
//' events: 'IN_ATTRIB', 'IN_DELETE_SELF', and 'IN_IGNORED'. Although we
//' are only watching for 'IN_DELETE_SELF', the 'IN_IGNORED' is an
//' unwatched event that is unconditionally generated. We must wait for
//' both the 'IN_DELETE_SELF' and 'IN_IGNORED' events to ensure that
//' the file has been deleted.
//' @param fd An integer file descriptor
//' @param timeout_s An integer file with a timeout length
//' @return An integer with result: 0 for an unexpected, non-std err, -1 for an
//' error that set 'errno', -2 for a timeout, or 1 for success.
// [[Rcpp::export]]
int tiledb_wait_for_delete(const int fd, const int timeout_s) {
    // Allocate enough space in the event buffer to contain at least two
    // events.
    const uint len = 2 * (sizeof(struct inotify_event) + NAME_MAX + 1);
    char buf[len];  // Read from the inotify fd until 'buf' contains two events.
    uint buf_offset = 0;
    for (;;) {
        // Wait for an event to read, timing out as necessary.
        const int rc = tiledb_poll(fd, timeout_s);
        if (rc <= 0) {
            return rc;
        }
        const int bytes = read(fd, (buf + buf_offset), (len - buf_offset));
        buf_offset += bytes;
        if (bytes <= 0) {
            return -1;
        }
        // Determine how many events are now contained within 'buf'.
        uint num_events = 0;
        uint event_offset = 0;
        for (;;) {
            // Check if we have enough unread bytes in 'buf' to contain at least
            // one event.
            if ((buf_offset - event_offset) < sizeof(struct inotify_event)) {
                break;
            }
            const struct inotify_event *const event =
                (const struct inotify_event *const)(buf + event_offset);
            event_offset += sizeof(struct inotify_event);
            // Check if we have enough unread bytes in 'buf' to contain the
            // variable-length contents of 'event'.
            if ((buf_offset - event_offset) < event->len) {
                break;
            }
            event_offset += event->len;
            // Increment the number of events in 'buf'.
            num_events += 1;
        }

        // If 'buf' contains two events, we're done.
        if (num_events >= 2) {
            break;
        }
    }

    // The first event should represent 'IN_DELTE_SELF'.
    uint event_offset = 0;
    const struct inotify_event *event = (struct inotify_event *)(buf + event_offset);
    if (!(event->mask & IN_DELETE_SELF)) {
        return 0;
    }
    event_offset += sizeof(struct inotify_event) + event->len;

    // The second event should represent 'IN_IGNORED'.
    event = (struct inotify_event *)(buf + event_offset);
    if (!(event->mask & IN_IGNORED)) {
        return 0;
    }
    event_offset += sizeof(struct inotify_event) + event->len;

    // Verify that we only read two events.
    if (event_offset != buf_offset) {
        return 0;
    }

    return 1;
}

//' Close a file descriptor
//'
//' @param fd An integer file descriptor
//' @return The result of the \code{close()} cal.
// [[Rcpp::export]]
int tiledb_close(const int fd) {
    return close(fd);
}

//' Close a \code{mmap}'ed pointer
//'
//' @param ep An external pointer to the \code{mmap}'ed file
// [[Rcpp::export]]
void tiledb_free(SEXP ep) {
    if (TYPEOF(ep) != EXTPTRSXP) {
        Rcpp::stop("expect an externalptr");
    }
    void* ptr = R_ExternalPtrAddr(ep);
    free(ptr);
    R_ClearExternalPtr(ep);
}

//' \code{munmap} a pointer
//'
//' @param ep A external pointer to the allocated \code{mmap} segment
//' @param length A size_t (integer) length of the \code{mmap} segment
//' @return The result from \code{munmap}
// [[Rcpp::export]]
int tiledb_munmap(SEXP ep, const size_t length) {
    if (TYPEOF(ep) != EXTPTRSXP) {
        Rcpp::stop("expect an externalptr");
    }
    void* addr = R_ExternalPtrAddr(ep);
    return munmap(addr, length);
}

//' Initialize an \sQuote{inotify} instance
//'
//' @return The result from \code{inotify_init}.
// [[Rcpp::export]]
int tiledb_inotify_init() {
    return inotify_init();
}

//' Remove an \sQuote{inotify} watch
//'
//' @param fd An integer file descriptor
//' @param wd An integer watch descriptor
//' @return The result from \code{inotify_rm_watch}
// [[Rcpp::export]]
int tiledb_inotify_rm_watch(const int fd, const int wd) {
    return inotify_rm_watch(fd, wd);
}

//' Return the error code as text
//'
//' @return A character variable with the error text for
//' the current \code{errno}
// [[Rcpp::export]]
std::string tiledb_strerror() {
    return std::string(strerror(errno));
}

//' Write IntegerVector to External Pointer address
//'
//' @param xptr An external pointer (which a mmap'ed file)
//' @param vec An integer vector
// [[Rcpp::export]]
void tiledb_mmap_write(SEXP xptr, Rcpp::IntegerVector vec) {
    //Rcpp::Rcout << "Vector to be written\n";
    //Rcpp::print(vec);
    void *ptr = R_ExternalPtrAddr(xptr);
    if (ptr == nullptr) Rcpp::stop("pointer is null in tiledb_mmap_write");
    // Rcpp::Rcout << "MMAP address ptr is " << ptr << std::endl;
    //Rcpp::Rcout << "About to copy " << vec.size() * sizeof(int) << " bytes" << std::endl;
    memcpy(ptr, &(vec[0]), vec.size() * sizeof(int));
    //Rcpp::Rcout << "Written" << std::endl;
}

//' Read n bytes into IntegerVector from External Pointer address
//'
//' @param xptr An external pointer (which a mmap'ed file)
//' @param bytes An integer with the number of bytes (not elements)
//' @return An integer vector
// [[Rcpp::export]]
Rcpp::IntegerVector tiledb_mmap_read(SEXP xptr, int bytes) {
    void *ptr = R_ExternalPtrAddr(xptr);
    if (ptr == nullptr) Rcpp::stop("pointer is null in tiledb_mmap_read");
    //Rcpp::Rcout << "MMAP address ptr is " << ptr << std::endl;
    int n = bytes / sizeof(int);
    Rcpp::IntegerVector vec(n);
    memcpy(&(vec[0]), ptr, bytes);
    return vec;
}

#endif
