// this define is important to no include another logger pulling in stdout
#define SPDLOG_DISABLE_DEFAULT_LOGGER 1

// this portmanteau include also defines the r_sink we use below, and which
// diverts all logging to R via the Rcpp::Rcout replacement for std::cout
#include <RcppSpdlog>

//' Set a new default logger for R
//'
// [[Rcpp::export]]
void setDefault() {
    std::string logname = "fromR"; 							// fix a name for this logger
    auto sp = spdlog::get(logname);        					// retrieve existing one
    if (sp == nullptr) sp = spdlog::r_sink_mt(logname);   	// or create new one if needed
    sp->set_pattern("[%H:%M:%S.%f] [%^%L%$] %v");
    spdlog::set_default_logger(sp);
}

//' Set a message at level \sQuote{info}
//'
//' @param s Character variable with the log message
// [[Rcpp::export]]
void logInfoMsg(std::string s) {
    spdlog::info(s.c_str());
    std::string logname = "fromR"; 							// fix a name for this logger
}

//' Sets the log level to critical
//'
// [[Rcpp::export]]
void setLogLevelCritical() {
    spdlog::set_level(spdlog::level::critical);
}
